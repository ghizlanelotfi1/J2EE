package com.example.InventoryServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
