package com.example.GitewayService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitewayServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
