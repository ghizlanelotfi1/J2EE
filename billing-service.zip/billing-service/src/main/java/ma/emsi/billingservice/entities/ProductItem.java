package ma.emsi.billingservice.entities;

import ma.emsi.billingservice.model.Product;

import javax.persistence.*;

@Entity
public class ProductItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double quantity;
    private double price;
    private long productItem;
    @ManyToOne
    private Bill bill;
    @Transient
    private Product product;
}
