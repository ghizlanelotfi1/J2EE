package com.example.authentfication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthentficationApplicationTests {

    @Test
    void contextLoads() {
    }

}
